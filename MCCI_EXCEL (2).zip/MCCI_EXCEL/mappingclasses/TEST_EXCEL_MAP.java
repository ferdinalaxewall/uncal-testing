package mappingclasses;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Every node name has no space
 * Then we are using 'space' to delimit node names
 *
 * For your own convenience, please just replace the numeric code
 * with reasonable key name, preverably use the Replace All
 * with whole word checked on your text editor.
 */
public class TEST_EXCEL_MAP {
	private final String SOURCE_NAME = "DPR_Message";
	private final String DESTINATION_NAME = "TEST_EXCEL";
	private final String SOURCE_TYPE = "EXCEL";
	private final String DESTINATION_TYPE = "XML";
	private final String COMPILATION_TIME = "Friday, 16 June 2023 13:17:05 +0700";

	public TEST_EXCEL_MAP() {
	}

	public String getSourceName() {
		return SOURCE_NAME;
	}

	public String getDestinationName() {
		return DESTINATION_NAME;
	}

	public String getSourceType() {
		return SOURCE_TYPE;
	}

	public String getDestinationType() {
		return DESTINATION_TYPE;
	}

	public String getCompilationTime() {
		return COMPILATION_TIME;
	}

	public Map<String, String> source() {
		Map<String, String> map = new LinkedHashMap<>();
		return map;
	}

	public Map<String, String> destination() {
		Map<String, String> map = new LinkedHashMap<>();
		return map;
	}

	public Map<String, String> map() {
		Map<String, String> map = new LinkedHashMap<>();
		return map;
	}

	public static void main(String[] args) {
		System.out.println("Accessing main method of class TEST_EXCEL_MAP!");
	}
}
